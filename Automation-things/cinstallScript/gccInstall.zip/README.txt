Linux:
    In the terminal locate this folder using the cd command
    Run the command:
    	sudo bash cinstall.sh
    Enter your password and answer Y (yes) for any prompts
    If succussfull the second to last line should display your version number of gcc

Windows:
    Right click on the cinstall.bat and select Run as Administrator (Admin).
    Enter A to accept all when prompted.
    If succussfull the second to last line should display your version number of gcc.
    
Ubuntu/Debian(Windows):
    If you downloaded either Debian or Ubuntu from the Windows Store, locate this folder.
    Run the command in the Linux section of this file.
    If succussfull the second to last line should display your version number of gcc
Mac:
    You're done, gcc comes pre-installed on OSX.
